import nltk
# download data
# nltk.download()
from nltk.corpus import dependency_treebank
import numpy as np

from Chu_Liu_Edmonds_algorithm import min_spanning_arborescence_nx
from arc import Arc

NODE_TAG = 'tag'

NODE_WORD = 'word'

NODE_DEPS = 'deps'

POS = "POS"

WORD = "WORD"

ROOT = "ROOT"

class MSTParser:
    def __init__(self, words, eta):
        self.eta = eta
        self.w = None
        self.v, self.p = None, None
        self.feature_mapping = {}
        self.init_data_sizes(words)

    def init_data_sizes(self, words):
        unique_words = set()
        unique_poses = set()
        for word, pos in words:
            unique_words.add(word)
            unique_poses.add(pos)
        self.v, self.p = len(unique_words), len(unique_poses)
        words_mapping = {word: i for i, word in enumerate(unique_words)}
        pos_mapping = {pos : i for i, pos in enumerate(unique_poses)}
        self.feature_mapping = {**words_mapping, **pos_mapping,
                                ROOT: self.v ** 2 + self.p ** 2}


    def get_feature_index(self, feature, feautre_type):
        head, tail  = feature
        if feautre_type == WORD:
            return self.feature_mapping[head] * self.v +\
                   self.feature_mapping[tail]
        if feautre_type == POS:
            return self.v**2 + self.feature_mapping[head] * self.p + \
                   self.feature_mapping[tail]

    def train(self, train_parsed_sentences, epochs):
        weights = []
        weights.append(np.zeros(self.v**2 + self.p**2 + 1))
        gold_standart_trees = dependency_treebank.parsed_sents()
        for epoch in range(epochs):
            for i in range(1, len(train_parsed_sentences)):
                if i == 0:
                    G = self.get_sentence_full_graph(train_parsed_sentences[i],
                                         np.zeros(self.v**2 + self.p**2 + 1))
                else:
                    G = self.get_sentence_full_graph(train_parsed_sentences[i],
                                                     weights[-1])
                mst = self.get_mst_from_sentence(G)
                diff = self.get_tree_vec_sum(gold_standart_trees[i]) - \
                self.get_tree_vec_sum(mst)
                sentence_weights = weights[-1] + eta * diff
                weights.append(sentence_weights)
        self.w = np.mean(weights)

    def get_sentence_full_graph(self, sentence, weights):
        graph = []
        for head in sentence.nodes:
            for tail in sentence.nodes:
                minus_weight = -1*self.caluclate_arc_score(head, tail, weights)
                graph.append(Arc(head, tail, minus_weight))
        return graph

    def parse(self, sentence):
        # parse the sentence
        pass


    def get_mst_from_sentence(self, G):
        return min_spanning_arborescence_nx(G, 0)

    def get_tree_vec_sum(self, parsed_sent) -> np.ndarray:
        arcs_vecs = []
        for head_node in parsed_sent.nodes:
            for tail_node in head_node[NODE_DEPS]:
                head = head_node[NODE_WORD], head_node[NODE_TAG]
                tail = tail_node[NODE_WORD], tail_node[NODE_TAG]
                arcs_vecs.append(self.extract_feature_function(head, tail))
        return np.sum(arcs_vecs)

    def caluclate_arc_score(self, head, tail, weights) -> float:
        # calculate the score of the arc
        return weights @ self.extract_feature_function(head, tail)


    def extract_feature_function(self, head, tail):
        # extract features from the dependency tree
        vec = np.zeros(self.v**2 + self.p**2 + 1)
        vec[self.get_feature_index((head, tail), WORD)] = 1
        vec[self.get_feature_index((head, tail), POS)] = 1
        return vec


if __name__ == '__main__':
    epochs = 2
    eta = 1
    parsed_sents = dependency_treebank.parsed_sents()
    train_portion = int((len(parsed_sents) * 0.9) // 10)
    parser = MSTParser(words=dependency_treebank.tagged_words(), eta=eta)
    parser.train(dependency_treebank.parsed_sents(), epochs=epochs)