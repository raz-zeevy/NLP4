class Arc:
    def __init__(self, head, tail, weight):
        self.head = head
        self.tail = tail
        self.weight = weight

    def __repr__(self):
        return f"({self.head}, {self.tail}, {self.weight})"

    def __eq__(self, other):
        return self.head == other.head and self.tail == other.tail and \
               self.weight == other.weight